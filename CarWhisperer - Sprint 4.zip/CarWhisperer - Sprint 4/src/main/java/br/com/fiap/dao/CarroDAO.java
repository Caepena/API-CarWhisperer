package br.com.fiap.dao;

import br.com.fiap.to.CarroTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CarroDAO extends Repository {
    public ArrayList<CarroTO> findAll() {
        ArrayList<CarroTO> carros = new ArrayList<>();
        String sql = "select * from carro order by idveiculo";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    CarroTO carro = new CarroTO();
                    carro.setIDVeiculo(rs.getLong("idveiculo"));
                    carro.setPlaca(rs.getString("placa"));
                    carro.setAno(rs.getInt("ano"));
                    carro.setCodCliente(rs.getLong("idcliente"));
                    carros.add(carro);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return carros;
    }

    public CarroTO findByCodigo(Long IDVeiculo) {
        CarroTO carro = new CarroTO();
        String sql = "select * from carro where idveiculo = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, IDVeiculo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                carro.setPlaca(rs.getString("placa"));
                carro.setAno(rs.getInt("ano"));
                carro.setIDVeiculo(rs.getLong("idveiculo"));
                carro.setCodCliente(rs.getLong("idcliente"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return carro;
    }

    public CarroTO save(CarroTO carro) {
        String sql = "insert into carro(idcliente, placa, ano) values(?, ?, ?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, carro.getCodCliente());
            ps.setString(2, carro.getPlaca());
            ps.setInt(3, carro.getAno());
            if (ps.executeUpdate() > 0) {
                return carro;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long IDVeiculo) {
        String sql = "delete from carro where idveiculo = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, IDVeiculo);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao excluir: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public CarroTO update(CarroTO carro) {
        String sql = "update carro set placa = ?, ano = ?, idcliente = ? where idveiculo = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, carro.getPlaca());
            ps.setInt(2, carro.getAno());
            ps.setLong(3, carro.getCodCliente());
            ps.setLong(4, carro.getIDVeiculo());
            if (ps.executeUpdate() > 0) {
                return carro;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
