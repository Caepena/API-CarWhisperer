package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;

public class CarroTO {
    private Long IDVeiculo;
    @NotBlank
    private Long codCliente;
    @Size(min = 7)
    private String placa;
    @PastOrPresent
    private Integer ano;

    public CarroTO() {

    }

    public CarroTO(Long IDVeiculo,@NotBlank Long codCliente, @Size(min = 7) String placa, @PastOrPresent Integer ano) {
        this.IDVeiculo = IDVeiculo;
        this.codCliente = codCliente;
        this.placa = placa;
        this.ano = ano;
    }

    public Long getIDVeiculo() {
        return IDVeiculo;
    }

    public void setIDVeiculo(Long IDVeiculo) {
        this.IDVeiculo = IDVeiculo;
    }

    public Long getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(Long codCliente) {
        this.codCliente = codCliente;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public Integer getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }
}
