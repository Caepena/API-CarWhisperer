package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public class SinistroTO {
    private Long IDSinistro;
    @NotBlank
    private Long codVeiculo;
    @PastOrPresent
    private LocalDate dataSinistro;
    @NotNull
    private Double valorEstimado;
    @Size(min = 30, max = 200)
    private String descricao;

    public SinistroTO() {

    }

    public SinistroTO(Long IDSinistro, @NotBlank Long codVeiculo, @PastOrPresent LocalDate dataSinistro,@NotNull Double valorEstimado, @Size(min = 30, max = 200) String descricao) {
        this.IDSinistro = IDSinistro;
        this.codVeiculo = codVeiculo;
        this.dataSinistro = dataSinistro;
        this.valorEstimado = valorEstimado;
        this.descricao = descricao;
    }

    public Long getIDSinistro() {
        return IDSinistro;
    }

    public void setIDSinistro(Long IDSinistro) {
        this.IDSinistro = IDSinistro;
    }

    public Long getCodVeiculo() {
        return codVeiculo;
    }

    public void setCodVeiculo(Long codVeiculo) {
        this.codVeiculo = codVeiculo;
    }

    public LocalDate getDataSinistro() {
        return dataSinistro;
    }

    public void setDataSinistro(LocalDate dataSinistro) {
        this.dataSinistro = dataSinistro;
    }

    public Double getValorEstimado() {
        return valorEstimado;
    }

    public void setValorEstimado(Double valorEstimado) {
        this.valorEstimado = valorEstimado;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
