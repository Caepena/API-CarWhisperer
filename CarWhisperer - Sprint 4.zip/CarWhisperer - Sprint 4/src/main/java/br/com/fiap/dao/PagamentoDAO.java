package br.com.fiap.dao;

import br.com.fiap.to.PagamentoTO;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PagamentoDAO extends Repository {
    public ArrayList<PagamentoTO> findAll() {
        ArrayList<PagamentoTO> pagamentos = new ArrayList<>();
        String sql = "select * from pagamento order by idpagamento";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    PagamentoTO pagamento = new PagamentoTO();
                    pagamento.setIDPagamento(rs.getLong("idpagamento"));
                    pagamento.setDataPagamento(rs.getDate("datapagamento").toLocalDate());
                    pagamento.setValor(rs.getDouble("valor"));
                    pagamento.setCodCliente(rs.getLong("idcliente"));
                    pagamentos.add(pagamento);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return pagamentos;
    }

    public PagamentoTO findByCodigo(Long IDPagamento) {
        PagamentoTO pagamento = new PagamentoTO();
        String sql = "select * from pagamento where idpagamento = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, IDPagamento);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                pagamento.setIDPagamento(rs.getLong("idpagamento"));
                pagamento.setDataPagamento(rs.getDate("datapagamento").toLocalDate());
                pagamento.setValor(rs.getDouble("valor"));
                pagamento.setCodCliente(rs.getLong("idcliente"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return pagamento;
    }

    public PagamentoTO save(PagamentoTO pagamento) {
        String sql = "insert into pagamento(datapagamento, valor, idcliente) values(?, ?, ?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(pagamento.getDataPagamento()));
            ps.setDouble(2, pagamento.getValor());
            ps.setLong(3, pagamento.getCodCliente());
            if (ps.executeUpdate() > 0) {
                return pagamento;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long idpagamento) {
        String sql = "delete from pagamento where idpagamento = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idpagamento);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao excluir: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public PagamentoTO update(PagamentoTO pagamento) {
        String sql = "update pagamento set datapagamento = ?, valor = ?, idcliente = ? where idpagamento = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(pagamento.getDataPagamento()));
            ps.setDouble(2, pagamento.getValor());
            ps.setLong(3, pagamento.getCodCliente());
            ps.setLong(4, pagamento.getIDPagamento());
            if (ps.executeUpdate() > 0) {
                return pagamento;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
