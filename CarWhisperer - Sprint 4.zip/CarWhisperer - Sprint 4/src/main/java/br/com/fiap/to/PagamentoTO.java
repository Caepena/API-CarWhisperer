package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;

import java.time.LocalDate;

public class PagamentoTO {
    private Long IDPagamento;
    @NotBlank
    private Long codCliente;
    @PastOrPresent
    private LocalDate dataPagamento;
    @NotNull
    private Double valor;

    public PagamentoTO() {

    }

    public PagamentoTO(Long IDPagamento, @NotBlank Long codCliente, @PastOrPresent LocalDate dataPagamento, @NotNull Double valor) {
        this.IDPagamento = IDPagamento;
        this.codCliente = codCliente;
        this.dataPagamento = dataPagamento;
        this.valor = valor;
    }

    public Long getIDPagamento() {
        return IDPagamento;
    }

    public void setIDPagamento(Long IDPagamento) {
        this.IDPagamento = IDPagamento;
    }

    public Long getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(Long codCliente) {
        this.codCliente = codCliente;
    }

    public LocalDate getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(LocalDate dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }
}
