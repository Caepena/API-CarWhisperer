package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public class ClienteTO {
    private Long IDCliente;
    @NotBlank
    private String nome, endereco;
    @Size(min = 11, max = 14)
    private String cpf;

    public ClienteTO() {

    }

    public ClienteTO(Long IDCliente, @NotBlank String nome, @NotBlank String endereco, @Size(min = 11, max = 14) String cpf) {
        this.IDCliente = IDCliente;
        this.nome = nome;
        this.endereco = endereco;
        this.cpf = cpf;
    }

    public Long getIDCliente() {
        return IDCliente;
    }

    public void setIDCliente(Long IDCliente) {
        this.IDCliente = IDCliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

}
