package br.com.fiap.dao;

import br.com.fiap.to.ClienteTO;
import br.com.fiap.to.SinistroTO;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class SinistroDAO extends Repository {
    public ArrayList<SinistroTO> findAll() {
        ArrayList<SinistroTO> sinistros = new ArrayList<>();
        String sql = "select * from sinistro order by idsinistro";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    SinistroTO sinistro = new SinistroTO();
                    sinistro.setIDSinistro(rs.getLong("idsinistro"));
                    sinistro.setDataSinistro(rs.getDate("datasinistro").toLocalDate());
                    sinistro.setValorEstimado(rs.getDouble("valorestimado"));
                    sinistro.setDescricao(rs.getString("descricao"));
                    sinistro.setCodVeiculo(rs.getLong("idveiculo"));
                    sinistros.add(sinistro);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return sinistros;
    }

    public SinistroTO findByCodigo(Long IDSinistro) {
        SinistroTO sinistro = new SinistroTO();
        String sql = "select * from sinistro where idsinistro = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, IDSinistro);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                sinistro.setIDSinistro(rs.getLong("idsinistro"));
                sinistro.setCodVeiculo(rs.getLong("idveiculo"));
                sinistro.setDescricao(rs.getString("descricao"));
                sinistro.setDataSinistro(rs.getDate("datasinistro").toLocalDate());
                sinistro.setValorEstimado(rs.getDouble("valorestimado"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return sinistro;
    }

    public SinistroTO save(SinistroTO sinistro) {
        String sql = "insert into sinistro(datasinistro, valorestimado, descricao, idveiculo) values(?, ?, ?, ?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(sinistro.getDataSinistro()));
            ps.setDouble(2, sinistro.getValorEstimado());
            ps.setString(3, sinistro.getDescricao());
            ps.setLong(4, sinistro.getCodVeiculo());
            if (ps.executeUpdate() > 0) {
                return sinistro;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long idsinistro) {
        String sql = "delete from sinistro where idsinistro = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idsinistro);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao excluir: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public SinistroTO update(SinistroTO sinistro) {
        String sql = "update sinistro set datasinistro = ?, valorestimado = ?, descricao = ?, idveiculo = ? where idsinistro = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(sinistro.getDataSinistro()));
            ps.setDouble(2, sinistro.getValorEstimado());
            ps.setString(3, sinistro.getDescricao());
            ps.setLong(4, sinistro.getCodVeiculo());
            ps.setLong(5, sinistro.getIDSinistro());
            if (ps.executeUpdate() > 0) {
                return sinistro;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
